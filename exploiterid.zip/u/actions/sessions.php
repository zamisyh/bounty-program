<?php 

	if (!isset($_SESSION['loginU'])) {
		header("Location: ../login ");
	}

 ?>
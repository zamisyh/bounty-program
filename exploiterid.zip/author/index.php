<?php 

	header("Location: ../index");

 ?>